import { TestBed, inject } from '@angular/core/testing';

import { FootballDataService } from './football-data.service';
import { AuthService } from './auth.service';

describe('FootballDataService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [FootballDataService, AuthService]
    });
  });

  it('should be created', inject([FootballDataService], (service: FootballDataService) => {
    expect(service).toBeTruthy();
  }));
});
