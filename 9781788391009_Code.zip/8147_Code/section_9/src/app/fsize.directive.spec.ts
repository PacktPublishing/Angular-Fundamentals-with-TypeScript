import { FsizeDirective } from './fsize.directive';
import { Directive, Input, ElementRef } from '@angular/core';

describe('FsizeDirective', () => {
  it('should create an instance', () => {
    const directive = FsizeDirective;
    expect(directive).toBeTruthy();
  });
});
