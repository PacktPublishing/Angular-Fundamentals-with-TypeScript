import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FootballDataService } from '../football-data.service';
import { AuthService } from '../auth.service';

import { PlayersComponent } from './players.component';

describe('PlayersComponent', () => {
  let component: PlayersComponent;
  let fixture: ComponentFixture<PlayersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlayersComponent ],
      providers: [FootballDataService, AuthService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlayersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should player list equal to 4', () => {
    expect(component.playerList.length).toEqual(4);
  });
});
