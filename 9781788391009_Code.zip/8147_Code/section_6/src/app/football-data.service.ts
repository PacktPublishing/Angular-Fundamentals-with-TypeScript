import { Injectable } from '@angular/core';
import { AuthService } from './auth.service';

@Injectable()
export class FootballDataService {
  playerList: object[] = [
    {
      name: 'Cristano Ronaldo'
    },
    {
      name: 'Lionel Messi'
    },
    {
      name: 'Neymar'
    },
    {
      name: 'Robert Lewandowski'
    }
  ]
  constructor(private auth: AuthService) { }

  getPlayerList () {
    return this.auth.isAuthorised() ? this.playerList : [];
  }

}
