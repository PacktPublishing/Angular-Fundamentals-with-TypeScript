import { Component } from '@angular/core';
import { FootballDataService } from './football-data.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  playerList: object[];
  title = 'angular template';
  disabledBtn = true;
  titleColor = 'red';
  name = 'John';

  constructor (private footballData: FootballDataService) {}

  ngOnInit() {
    this.playerList = this.footballData.getPlayerList()
  }

  toggleTitleColor() {
    if (this.titleColor === 'red') {
      this.titleColor = 'blue';
    } else {
      this.titleColor = 'red';
    }
  }

  myMethod(event) {
    console.log(event.target.value);
    this.title = event.target.value;
  }
}
