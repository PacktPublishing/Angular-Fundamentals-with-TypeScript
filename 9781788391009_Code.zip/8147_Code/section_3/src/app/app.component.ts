import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angular template';
  disabledBtn = true;

  myMethod(event) {
    console.log(event.target.value);
    this.title = event.target.value;
  }
}
