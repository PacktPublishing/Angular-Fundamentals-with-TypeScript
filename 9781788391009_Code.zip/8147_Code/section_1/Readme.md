# Section 1 - GETTING STARTED WITH TYPESCRIPT 

## Commands

### install npm globally
```
  npm install npm -g
```

### install TypeScript globally
```
  npm install -g typescript
```


### Compile example.ts into example.js
```
  tsc example.ts --target ES6 
```

## TypeScript basics

### Variables
```js
  
let firstName: string = 'John';
let age: number = 26;
let isProgrammer: boolean = true;

let anything: any = 'john';
anything = 26;

const PI: number = 3.14;


```

### Arrays
```js

let players: string[] = ['ronaldo', 'messi', 'neymar'];

```

### Functions
```js

function getPlayerName(name: string, surname: string): string {
	return name + " " + surname;
}

console.log(getPlayerName('cristiano', 'ronaldo'));

```

### Classes
```js

class Person {
	public hobby: string;
	static numOfPersons: number = 0;

	constructor(private name: string, private age: number) {
		Person.numOfPersons++;
	}

	info() {
		console.log(this.name + " " + this.age);
	}
}

const john = new Person('John', 26);

console.log(john);
console.log(john.info());

class Player extends Person {
	constructor(name: string, age: number) {
		super(name, age);
	}
}

const ronaldo = new Player('Ronaldo', 32);

console.log(ronaldo);
console.log(ronaldo.info());

```
### Interfaces

```js

interface PersonInterface {
	name: string,
	age: number
}

const johnB: PersonInterface = {
	name: 'JohnB',
	age: 40
}

console.log(johnB);

interface Vehicle {
	drive(): any;
}

class Car implements Vehicle {
	drive(): void {
		console.log('driving a car');
	}	
}

class Bicycle implements Vehicle {
	drive(): void {
		console.log('driving a bike');
	}	
}

const car = new Car();
const bike = new Bicycle();

car.drive();
bike.drive();
```

### Generics

```js

const getType = function <T>(value: T): string {
	return typeof value
}

console.log(getType(false));
console.log(getType('john'));

function driveVehicle<vehicle extends Vehicle>(v: Vehicle): void {
	v.drive();
}

driveVehicle(car);
driveVehicle(bike);

class GenericString<T> {
	fullName(name: T, surname: T): void {

	}
}

```
