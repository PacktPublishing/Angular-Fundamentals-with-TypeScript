```javascript

const m = () => console.log('siema')

```
