import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FsizeDirective } from './fsize.directive';
import { FormComponent } from './form/form.component';

import { FootballDataService } from './football-data.service';
import { AuthService } from './auth.service';

import { Routes, RouterModule } from '@angular/router';
import { PlayersComponent } from './players/players.component';

import { HttpClientModule } from '@angular/common/http'

const appRoutes: Routes = [
  {
    path: 'login',
    component: FormComponent
  },
  {
    path: 'players',
    component: PlayersComponent
  }
]

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FsizeDirective,
    FormComponent,
    PlayersComponent
  ],
  imports: [
    BrowserModule,
    NgbModule.forRoot(),
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(appRoutes),
    HttpClientModule
  ],
  providers: [FootballDataService, AuthService],
  bootstrap: [AppComponent]
})
export class AppModule { }
