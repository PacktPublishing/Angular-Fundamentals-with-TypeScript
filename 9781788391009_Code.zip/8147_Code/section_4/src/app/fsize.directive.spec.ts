import { FsizeDirective } from './fsize.directive';

describe('FsizeDirective', () => {
  it('should create an instance', () => {
    const directive = new FsizeDirective();
    expect(directive).toBeTruthy();
  });
});
